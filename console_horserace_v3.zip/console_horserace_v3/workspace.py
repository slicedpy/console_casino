import csv

board = []
race_stats = []

with open('race_record.csv','rb') as loaded_record:
    race_record = csv.reader(loaded_record,delimiter=',',quotechar='"')
    header_check = 0
    
    for entry in race_record:
        if header_check == 0:
            header_check += 1
            pass
        else:
            try:
                board.index(entry[1])
            except ValueError:
                board.append(entry[1])
                
    header_check = 0

with open('race_record.csv','rb') as loaded_record:
    race_record = csv.reader(loaded_record,delimiter=',',quotechar='"')
    header_check = 0

    for horse in board:
        race_stats.append([horse,0,0,0])

    for entry in race_record:
        if header_check == 0:
            header_check += 1
            pass
        else:
            for each in race_stats:
                if str(entry[1]) == str(each[0]):
                    each[int(entry[0])] += 1

head_tags = ["Horse Name","1ST","2ND","3RD"]
gap = 18
head_line = "-"*(gap+1)*len(head_tags) + "\n"

for each in head_tags:
    spacer = gap - len(each)
    head_line += str(each) + " "*spacer + "|"

print head_line


for i in race_stats:
    line_made = ""
    for cell in i:
        if len(str(cell)) <= 3:
            line_made += " "*((gap/2)-len(str(cell))) + str(cell) + " "*(gap/2) + "|"
        else:
            line_made += str(cell) + " "*(gap-len(str(cell)))+ "|"
            
    print line_made


