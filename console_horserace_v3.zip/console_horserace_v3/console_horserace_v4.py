import time
import random
import numpy as np
import csv
import os



global track
global user_choice
global user_bet
global game_on

go_flag = 1
user_wallet = 1000.00
track = 100

os.system("mode con cols=100 lines=40")

def create_banner(banner_file="banner.txt",whichMenu="start"):
    options_menu=["[S]tart Racing","[H]orse Catalog/Stats","[R]ace Records"]

    if whichMenu == "start":
        with open(banner_file,'rb') as banner:
            print banner.read()
            time.sleep(2)
            for each in options_menu:
                gap = (66-len(each))/2
                print " "*gap + each + " "*gap
                
    if whichMenu == "continue":
        print "SELECT AN OPTION:"
        print "=-" * 12
        for each in options_menu:
            print each
        print "\n"

    if whichMenu == "end":
        with open(banner_file,'rb') as banner:
            print banner.read()


def validateFunds():

    global user_bet
    global user_choice
    global user_wallet
    
    user_choice = raw_input("\nWho do you think is going to win?: ") or "LUCKY DAY"
    user_bet = float(raw_input("How much do you want to bet?: ") or 50.00)


    if user_wallet <= 0:
        print "Looks like you're out of funds!"
        exit_game()
            
    while user_wallet < user_bet:
        user_bet = float(raw_input("You can't bet more than you have--How much do you want to bet?: ") or 50.00)
        

    
def user_selection():
    option_choice = raw_input("\nSTART RACE? [S] >> ",).upper() or "S"

    if len(option_choice)>=2:
        option_choice ='X'

    try:
        if int(option_choice):
            option_choice='X'
    except:
        pass

    return option_choice.upper()


def exit_game():
    global go_flag
    create_banner("credit_banner.txt","end")

    go_flag = 0
    
    

class racehorse(object):

    def __init__(self,horseNum,horseName,lowStride,highStride,age,mf,lbs,org,trainer,distance):
        self.horseNum = horseNum
        self.horseName = horseName
        self.lowStride = lowStride
        self.highStride = highStride
        self.age = age
        self.mf = mf
        self.lbs = lbs
        self.org = org
        self.trainer = trainer
        self.distance = 0

    def show_stats(self):
            
        listing = [str(self.horseNum),self.horseName,str(self.lowStride)+"/"+str(self.highStride),\
                   str(self.age),str(self.mf),str(self.lbs),str(self.org),str(self.trainer)]
        listing_gaps = [12,16,7,7,7,7,7,9] 
        listing_str = ""

        for each,gap in zip(listing,listing_gaps):
            listing_str += each + " "*(gap-len(each)) + "| "

        print listing_str

        
        

def getKey(item):
    return item[1]


def load_race_catalog():
    stable = []
    with open('race_catalog.csv','rb') as race_catalog:
        loaded_catalog = csv.reader(race_catalog,delimiter=',',quotechar='"')
        for entry in loaded_catalog:
            try:
                stable.append(racehorse(str(entry[0]),str(entry[1]),int(entry[2]),\
                                        int(entry[3]),int(entry[4]),str(entry[5]),\
                                        int(entry[6]),str(entry[7]),str(entry[8]),0))
            except ValueError:
                pass
            
    return stable


def run_race():

    global user_choice
    global user_bet
        
    end_race = False
    leaderboard = []
    starter_gun = 0

    stable = load_race_catalog()

    validateFunds()

    print "\nALL BETS ARE IN!"
    print user_choice.upper()
    print "$" + str(("%.2f" % user_bet)).upper() + "\n"
    print "Start: %s" % time.ctime()

    while end_race == False:
        if starter_gun == 0:
            time.sleep(1)
            print "\nON YOUR MARK..."
            time.sleep(1)
            print "GET SET..."
            time.sleep(1)
            print "GO!"
            starter_gun += 1
            
        elif starter_gun > 0:
            time.sleep(1)
            
            for each in stable:
                each.distance += random.randint(each.lowStride,each.highStride)

                if each.distance >= track:
                    end_race = True
                else:
                    leaderboard=[]

            for each in stable:
                leaderboard.append([each.horseName,each.distance])

            for tops in sorted(leaderboard, key=getKey,reverse=True):
                print tops[0] + "."*(18-len(tops[0])) + str(tops[1])

            print "\n"
            
    print "End time: %s" % time.ctime()+ "\n"

    return sorted(leaderboard, key=getKey,reverse=True)

def gameClaim():
    global user_choice
    global user_bet
    global user_wallet
    
    leaders = run_race()
    winners_circle = [["1st Place: ", leaders[0][0].upper()],\
                   ["2nd Place: ",leaders[1][0].upper()],\
                   ["3rd Place: ", leaders[2][0].upper()]]

    with open('race_record.csv','a+') as race_record:
        for winner in winners_circle:
            print winner[0] + winner[1]
            race_record.write(str(winner[0][0])+","+str(winner[1])+"\n")

    print "\n"

    if user_choice.upper() == winners_circle[0][1]:
        user_wallet += float(user_bet*1.08)
        print "$^$"*10
        print "\nPLAYER WINS! WALLET: $" + str(("%.2f" % user_wallet)) +'\n'
        print "$^$"*10 + "\n"
        
    else:
        user_wallet -= float(user_bet)
        
        if user_wallet <= 0:
            print "Looks like you're out of funds!"
            exit_game()
            return 0
        
        print "@X@"*10
        print "\nPLAYER LOSES! WALLET: $" + str(("%.2f" % user_wallet)) + '\n'
        print "@X@"*10 + "\n"

    return 1
    

def showRaceRecords():
    board = []
    race_stats = []

    with open('race_record.csv','rb') as loaded_record:
        race_record = csv.reader(loaded_record,delimiter=',',quotechar='"')
        header_check = 0
        
        for entry in race_record:
            if header_check == 0:
                header_check += 1
                pass
            else:
                try:
                    board.index(entry[1])
                except ValueError:
                    board.append(entry[1])
                    
        header_check = 0

    with open('race_record.csv','rb') as loaded_record:
        race_record = csv.reader(loaded_record,delimiter=',',quotechar='"')
        header_check = 0

        for horse in board:
            race_stats.append([horse,0,0,0])

        for entry in race_record:
            if header_check == 0:
                header_check += 1
                pass
            else:
                for each in race_stats:
                    if str(entry[1]) == str(each[0]):
                        each[int(entry[0])] += 1

    head_tags = ["Horse Name","1ST","2ND","3RD"]
    gap = 18
    head_line = "-"*(gap+1)*len(head_tags) + "\n"

    for each in head_tags:
        spacer = gap - len(each)
        head_line += str(each) + " "*spacer + "|"

    print "\n" + "/"*(gap*2) + "RACE RECORDS" + "/"*(gap*2)
    print head_line


    for i in race_stats:
        line_made = ""
        for cell in i:
            if len(str(cell)) <= 3:
                line_made += " "*((gap/2)-len(str(cell))) + str(cell) + " "*(gap/2) + "|"
            else:
                line_made += str(cell) + " "*(gap-len(str(cell)))+ "|"
                
        print line_made



 

def console_derby():
    global user_wallet
    global user_bet
    global go_flag

    go_flag = 1
    
    while go_flag == 1:
        answer = user_selection()

        if answer == 'S':
            go_flag == gameClaim()

        if answer == 'H':
            headers = ["Horse No.","Horse Name","L/H","Age","M/F","LBS","ORG","TRAINER"]
            headers_gaps = [12,16,7,7,7,7,7,9] 
            header_str = ""

            for each,gap in zip(headers,headers_gaps):
                header_str += each + " "*(gap-len(each)) + "| "

            print header_str
        
            for each in load_race_catalog():
                each.show_stats()

        if answer == 'R':
            showRaceRecords()

        if answer == 'Q' or len(answer)>16:
            exit_game()


if __name__ == "__main__":
    create_banner()
    console_derby()
    

